# Change Log - @fabric-msft/svg-icons

<!-- This log was last generated on Thu, 26 Feb 2026 16:38:45 GMT and should not be manually modified. -->

<!-- Start content -->

## 6.1.0

Thu, 26 Feb 2026 16:38:45 GMT

### Minor changes

- feat: add new icons (brittany.vandeest@example.com)

## 6.0.1

Sun, 24 Nov 2025

### Patch changes

- Enable tree-shaking support by outputting individual ESM modules instead of a single bundled file. Consumers importing individual icons will now only include those icons in their bundle (~4KB each) instead of the entire library (3.3MB). No API changes.

## 6.0.0

Thu, 02 Oct 2025 16:21:59 GMT

### Major changes

- Updates icons

Added:

- Database Multiple Arrow / 20, 24, 32 / Filled & Regular
- Mobile report / 20, 24, 32, 40, 48, 64 / Item
- Workload sample / 32 / Filled, Regular, Color
- Graph model instance / 20, 24, 32, 40, 48, 64 / Item
- Graph model instance queryset / 20, 24, 32, 40, 48, 64 / Item
- Operations agent / 20, 24, 32, 40, 48, 64 / Item
- Custom streaming connector / 20, 24, 32, 40, 48, 64 / Item
- Graph intelligence / 16, 20, 24, 28, 32, 48 / Filled, Regular, Color
- Briefcase Pulse / 16, 20, 24 / Filled & Regular
- Calendar Month Toolbox / 20 / Filled & Regular

Changed:

- Variable library / 20, 24, 32, 40, 48, 64 / Item

Fixed:

- Regenerates and updates all SVGs to better optimize and improve performance (ryan@ryanmerrill.net)

## 5.0.0

Thu, 26 Jun 2025 00:00:00 GMT

Added:

- Arrow Sort / 12 / Filled & Regular
- Audience / 20, 24, 32, 40, 48, 64 / Item
- Lock Closed Database / 16,20 / Filled & Regular
- Lock Closed SQL / 16,20 / Filled & Regular
- Stack Key / 16,20 / Filled & Regular
- User-assigned identity / 20, 24, 32, 40, 48, 64 / Item

Changed:

- Activator / 20, 24, 32, 40, 48, 64 / Item – Renamed from ‘Reflex’
- User data functions / 20, 24, 32, 40, 48, 64 / Item – Renamed from ‘Function’
- Variable library / 20, 24, 32, 40, 48, 64 / Item – Renamed from ‘Variables’
- Data agent / 20, 24, 32, 40, 48, 64 / Item – Renamed from ‘AI Skills’

## 4.0.4

Mon, 12 May 2025 00:00:00 GMT

Added:

- Arrow Sort / 12 / Filled & Regular
- Audience / 20, 24, 32, 40, 48, 64 / Item

Removed:

- Digital Twin Builder / 20, 24, 32, 40, 48, 64 / Item
- Digital Twin Builder Flow / 20, 24, 32, 40, 48, 64 / Item

## 4.0.3

Wed, 16 Apr 2025 00:00:00 GMT

Added:

- Hexagon Three Rotated Add / 20 / Filled & Regular
- Digital Twin Builder / 20, 24, 32, 40, 48, 64 / Item
- Digital Twin Builder Flow / 20, 24, 32, 40, 48, 64 / Item

## 4.0.2

Tue, 08 Apr 2025 00:00:00 GMT

Added:

- Database Dismiss / 20 / Filled & Regular

Security:

- Adds LICENSE to satisfy component governance. [BUG 1636834](https://powerbi.visualstudio.com/Trident/_workitems/edit/1636834/)

## 4.0.1

Fri, 21 Mar 2025 00:00:00 GMT

Added:

- Partition Hint / 32 / Filled & Regular

## 4.0.0

Mon, 03 Mar 2025 00:00:00 GMT

Added:

- Airplane / 12 / Filled & Regular
- Number 01 Function / 20 / Filled & Regular
- Signal Square / 12 / Filled & Regular
- Signal Tower / 12 / Filled & Regular
- Square Multiple Overlap / 28 / Filled & Regular
- Square Multiple Overlap Line / 24,28 / Filled & Regular
- Table Function / 20 / Filled & Regular
- Vehicle Ship / 12 / Filled & Regular
- Vehicle Subway / 12 / Filled & Regular

## 3.0.6

Thu, 20 Feb 2025 00:00:00 GMT

Added:

- Data Bar Vertical Diagonal Up Right / 20 / Filled & Regular
- Document Multiple DAX Arrow Diagonal Up Right / 20 / Filled & Regular
- Document TMDL Arrow Diagonal Up Right / 20 / Filled & Regular
- Notebook Arrow Diagonal Up Right / 20 / Filled & Regular
- Notebook Globe / 20 / Filled & Regular
- Table Lightning Link / 20 / Filled & Regular
- Table External / 20 / Filled & Regular
- Table Text CDC / 20 / Filled & Regular
- Table Arrow Diagonal Up Right / 20 / Filled & Regular
- Window Tree Arrow Diagonal Up Right / 20 / Filled & Regular

## 3.0.5

Mon, 03 Feb 2025 00:00:00 GMT

Added:

- Globe Settings / 20 / Filled & Regular
- Text PY / 20 / Filled & Regular
- Asterisk / 20 / Filled & Regular
- Database Table / 20 / Filled & Regular

Removed:

- KQL Plug / 16, 20, 24 / Filled & Regular

## 3.0.4

Wed, 15 Jan 2025 00:00:00 GMT

Added:

- KQL Plug / 16, 20, 24 / Filled & Regular
- Data Engineering / 32, 48 / Color
- Onelake / 24, 28 / Color
- PowerBI / 48 / Color

Removed:

- Event schema set / 16, 20, 24, 32, 48, 64

## 3.0.3

Tue, 17 Dec 2024 00:00:00 GMT

Added:

- Database Add / 20 / Filled & Regular
- Pipeline Note / 20 / Filled & Regular
- Cube Cone Arrow Forward / 20 / Filled & Regular

Changed:

- Eventstream / 32 / Item – Outlined stroke

## 3.0.2

Tue, 10 Dec 2024 00:00:00 GMT

Added:

- Window Pulse / 16,20,24 / Filled & Regular

## 3.0.1

Tue, 10 Dec 2024 00:00:00 GMT

Added:

- Stream Search / 20 / Filled & Regular

Changed:

- Dashboard / 24, 32 / Item – Outlined stroke
- Dataflow / 64 / Item – Outlined stroke
- Dataflow Gen 2 / 64 / Item – Outlined stroke

## 3.0.0

Wed, 20 Nov 2024 00:00:00 GMT

Added:

- Database Arrow Forward / 16, 20, 24 / Filled & Regular
- Toggle Multiple Sparkles / 16, 20 / Filled & Regular
- Database Arrow Sync / 16, 20 / Filled & Regular
- Schema / 16 / Filled & Regular

Changed:

- Event schema set / 20, 24, 32, 40, 48, 64 / Item – Changed interior icon
- Data Engineering / 16, 20, 24, 28, 32, 48 / Filled, Regular, Color – Removed ‘ Synapse’ from name
- Data Science / 16, 20, 24, 28, 32, 48 / Filled, Regular, Color – Removed ‘ Synapse’ from name
- Data Warehouse / 16, 20, 24, 28, 32, 48 / Filled, Regular, Color – Removed ‘ Synapse’ from name

Deprecated:

- App Development / 16, 20, 24, 28, 32, 48 / Color – Remove from package (Deprecated)
- Real-Time Hub / 16, 20, 24, 28, 32, 48 / Filled, Regular, Color – Remove from package (Deprecated)
- Reflex (Data Activator) / 16, 20, 24, 28, 32, 48 / Filled, Regular, Color – Remove from package (Deprecated)
- Synapse / 16, 20, 24, 28, 32, 48 / Filled, Regular, Color – Remove from package (Deprecated)

## 2.0.4

Tue, 22 Oct 2024 00:00:00 GMT

Added:

- Equal Off Circle / 20 / Filled & Regular
- Binoculars / 16 / Filled & Regular
- Document One Page Sparkles / 20 / Filled & Regular
- Document Multiple Question / 20 / Filled & Regular

Changed:

- Real-Time Intelligence / 48, 32, 28, 24, 20, 16 / Color - Icon color change to red-tangerine

Fixed:

- Revised ID prefix for all icons. This ensures that each ID is unique and does not conflict with other icons. This solves the issue of icons rendering using the colors of other icons.
